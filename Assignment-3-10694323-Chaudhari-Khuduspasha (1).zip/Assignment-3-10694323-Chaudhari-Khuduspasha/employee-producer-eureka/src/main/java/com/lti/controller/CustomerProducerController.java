package com.lti.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lti.model.Customer;
import com.lti.service.CustomerService;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
@RestController
@RequestMapping("/customer-producer")
public class CustomerProducerController {

	
	@Autowired
	private CustomerService service;
	
	@HystrixCommand(fallbackMethod = "producer", groupKey = "producer",
            commandKey = "producer",
            threadPoolKey = "producerThread"
            )
	@GetMapping("/getAllProducts")
	public ResponseEntity<?>getAllProducts(){
		List<Customer>productsList= service.getAll();
		
		if(productsList==null) {
			return new ResponseEntity<>("Products Not Found",HttpStatus.NO_CONTENT);
		}else {
			return new ResponseEntity<>(productsList,HttpStatus.OK);
	
		}
		
		
		}
	
	@HystrixCommand(fallbackMethod = "producer", groupKey = "producer",
            commandKey = "producer",
            threadPoolKey = "producerThread"
            )
	@PostMapping("/save")
	public ResponseEntity<?>save(@RequestBody Customer c){
		
		Customer customer =  service.save(c);
		if(customer!=null) {
			return new ResponseEntity<>(customer,HttpStatus.CREATED);
		}else {
			return new ResponseEntity<>("Product Not Found",HttpStatus.FAILED_DEPENDENCY);	
		}
	}
	
	@HystrixCommand(fallbackMethod = "producer", groupKey = "producer",
            commandKey = "producer",
            threadPoolKey = "producerThread"
            )
	 @GetMapping("/findByid/{id}")
	public ResponseEntity<?>getByid(@PathVariable("id") Integer id){
		Customer customer =  service.getByid(id);
		if(customer!=null) {
			return new ResponseEntity<>(customer,HttpStatus.FOUND);
		}else {
			return new ResponseEntity<>("Product Not Found",HttpStatus.NOT_FOUND);	
		}
	}
	 
	@HystrixCommand(fallbackMethod = "producer", groupKey = "producer",
            commandKey = "producer",
            threadPoolKey = "producerThread"
            )
	 @PostMapping("/update")
		public ResponseEntity<?>update(@RequestBody Customer c){
			
			boolean customer =  service.update(c);
			if(customer==true) {
				return new ResponseEntity<>(customer,HttpStatus.CREATED);
			}else {
				return new ResponseEntity<>(customer,HttpStatus.FAILED_DEPENDENCY);	
			}
		}
		 
	@HystrixCommand(fallbackMethod = "producer", groupKey = "producer",
            commandKey = "producer",
            threadPoolKey = "producerThread"
            )
	 @PostMapping("/deleteByid/{id}")
		public ResponseEntity<?>deleteByid(@PathVariable("id") Integer id){
			boolean customer =  service.deleteById(id);
			if(customer==true) {
				return new ResponseEntity<>(customer,HttpStatus.OK);
			}else {
				return new ResponseEntity<>(customer,HttpStatus.FAILED_DEPENDENCY);	
			}
		}
	 

	 public String fallback(Throwable hystrixCommand) {
	        return "Fall Back Called in Coustomer Consumer";
	    }
	 
	}

