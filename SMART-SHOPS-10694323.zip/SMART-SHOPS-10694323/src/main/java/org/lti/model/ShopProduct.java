package org.lti.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="ShopProduct")
public class ShopProduct {

	
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	private Integer productId;
	
	@Column(name="Product_name",nullable = false)
	private String name;
	
	@Column(name="category",nullable = false)
	private String category;
	
	@Column(name="quantity")
	private Integer qty;
	
	@Column(name="unitPrice",nullable = false)
	private double unitPrice;
	
	@Column(name="totalPrice")
	private double totalPrice;
	
	
	@Column(name="rating",nullable = false)
	private Integer rating;
	
	
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", name=" + name + ", category=" + category + ", qty=" + qty
				+ ", unitPrice=" + unitPrice + ", totalPrice=" + totalPrice + ", rating=" + rating + "]";
	}



	public ShopProduct() {
		super();
	}

	

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public Integer getQty() {
		return qty;
	}

	public void setQty(Integer qty) {
		this.qty = qty;
	}

	public double getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}

	public double getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}

	

	public Integer getRating() {
		return rating;
	}

	public void setRating(Integer rating) {
		this.rating = rating;
	}

}
