package org.lti.repository;

import org.lti.model.ShopProduct;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
@Repository

public interface ProductRepository extends JpaRepository<ShopProduct, Integer> {



	public ShopProduct findByName(String name);
	
	public ShopProduct findByCategory(String category);
}
