package org.lti.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.lti.dto.ProductDto;
import org.lti.exception.ItemNotFoundException;
import org.lti.model.ShopProduct;
import org.lti.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ShopServiceImpl implements ShopService {
	static final Logger logger = Logger.getLogger(ShopServiceImpl.class);


	@Autowired
	private ProductRepository repo;
	
	@Override
	@Transactional(readOnly=true)
	public List<ShopProduct> getAllProduct() throws ItemNotFoundException {
		logger.info("Entered getAllProduct");

		 List<ShopProduct>productList=repo.findAll();
			try {
				if(productList!=null) 
					return productList;
					else
						throw new ItemNotFoundException("Product Not Founds");
	         } catch (Exception e) {
		
	            }
			return null;
		}


	// save product
	@Override
	@Transactional
	public ShopProduct save(ProductDto dto) throws ItemNotFoundException {
		try {
			logger.info("Entered into save");
			ShopProduct p=new ShopProduct();
			 p.setName(dto.getName());
			 p.setCategory(dto.getCategory());
			 p.setQty(dto.getQty());
			 p.setRating(dto.getRating());
			 p.setUnitPrice(dto.getUnitPrice());
			  
			 ShopProduct savedProduct=repo.save(p);
			 if(savedProduct!=null) {
				 return savedProduct;
			 }else
				 throw new ItemNotFoundException("Product Not Saved");
		} catch (Exception e) {
			logger.error("Exception occure while saving Product="+dto.getName());
			e.printStackTrace();
		}
		return null;
	}


	@Override
	@Transactional
	public ShopProduct update(ProductDto dto) throws ItemNotFoundException {
		logger.info("Entered into update");

		try {
			if(dto!=null) {
				ShopProduct p=repo.getOne(dto.getProductId());
				if(p==null)
					throw new ItemNotFoundException("Product Not Found");
				else {
					p.setName(dto.getName());
					 p.setCategory(dto.getCategory());
					 p.setQty(dto.getQty());
					 p.setRating(dto.getRating());
					 p.setUnitPrice(dto.getUnitPrice());
					 ShopProduct savedProduct=repo.save(p);
					return savedProduct;
				}	
			}
		} catch (Exception e) {
		logger.error("Exception occure while update Product="+dto.getProductId());
			e.printStackTrace();
		}
		return null;
	}


	@Override
	@Transactional(readOnly=true)
	public ProductDto getByProductName(String name) {
		
		try {
			ShopProduct p= repo.findByName(name);
			if(p==null)
           throw new ItemNotFoundException("Product Not Found");
			
			ProductDto dto=new ProductDto();
			dto.setCategory(p.getCategory());
			dto.setName(p.getName());
			dto.setQty(p.getQty());
			dto.setRating(p.getRating());
			dto.setUnitPrice(p.getUnitPrice());
			dto.setTotalPrice(p.getTotalPrice());
			dto.setProductId(p.getProductId());
			 return dto;
		} catch (Exception e) {
	logger.error("Exception occure while geting productBy name ="+name);
	
		}		
		return null;
	}


	@Override
	@Transactional(readOnly=true)
	public ProductDto getByProductCategory(String category) {

		try {
			ShopProduct p= repo.findByCategory(category);
			if(p==null)
           throw new ItemNotFoundException("Product Not Found");
			
			ProductDto dto=new ProductDto();
			dto.setCategory(p.getCategory());
			dto.setName(p.getName());
			dto.setQty(p.getQty());
			dto.setRating(p.getRating());
			dto.setUnitPrice(p.getUnitPrice());
			dto.setTotalPrice(p.getTotalPrice());
			dto.setProductId(p.getProductId());
			 return dto;
		} catch (Exception e) {
	  logger.error("Exception occure while geting productBy category ="+category);	
		}
		return null;
	}


	@Override
	@Transactional
	public Integer deleteProductLessRetings() {
		logger.info("Entred into deleteProductLessRetings Method ");
		Integer count=0;

		 List<ShopProduct>productList=repo.findAll();
			try {
				if(productList==null) 
					throw new ItemNotFoundException("Product Not Founds");
				else {
					if(productList.size()>0){
						for(ShopProduct p:productList) {
							if(p.getRating()<2) {
								repo.delete(p);
								count++;
							}	
						}
					return count;
					}
				}
	         } catch (Exception e) {
logger.error("Exception occure while deleteing productBy less retings");	    
	         }
			return count;
		}


	@Override
	@Transactional
	public String updatedTotalPrice(Integer id)  {
		try {
			String updateMsg="Already Updated";
			ShopProduct p=repo.getOne(id);
			if(p==null)
			throw new ItemNotFoundException("Product Not Founds");
			
			if(p.getTotalPrice()!=0){
				return updateMsg;
			}else {
				p.setTotalPrice(p.getUnitPrice()*p.getQty());
				ShopProduct savedProduct=repo.save(p);
				return "Price Update="+savedProduct.getTotalPrice();
			}
		} catch (Exception e) {
			logger.error("Exception occure while deleteing productBy less retings");	    

			e.printStackTrace();
		}

		return null;
	}

	}

