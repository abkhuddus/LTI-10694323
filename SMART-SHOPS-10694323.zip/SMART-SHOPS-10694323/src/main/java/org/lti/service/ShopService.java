package org.lti.service;

import java.util.List;

import org.lti.dto.ProductDto;
import org.lti.exception.ItemNotFoundException;
import org.lti.model.ShopProduct;
import org.springframework.stereotype.Service;

@Service
public interface ShopService {

	public List<ShopProduct>getAllProduct()throws ItemNotFoundException;

	public ShopProduct save(ProductDto  dto)throws ItemNotFoundException;
	
	public ShopProduct update(ProductDto  dto)throws ItemNotFoundException;

	
	public ProductDto getByProductName(String name)throws ItemNotFoundException;
	
	public ProductDto getByProductCategory(String category)throws ItemNotFoundException;
	
	public Integer deleteProductLessRetings()throws ItemNotFoundException;
	
	public String updatedTotalPrice(Integer id);
	
}
