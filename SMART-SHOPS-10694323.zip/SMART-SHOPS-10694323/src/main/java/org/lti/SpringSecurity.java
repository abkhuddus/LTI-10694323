package org.lti;

//@Configuration
//@EnableWebSecurity
public class SpringSecurity {//extends WebSecurityConfigurerAdapter {
	
	//NOTE$$$$$$$$  remove comments to test with secuirty 
	
	/*
	 * @Override protected void configure(AuthenticationManagerBuilder auth) throws
	 * Exception {
	 * 
	 * auth.inMemoryAuthentication()
	 * .withUser("user").password("{noop}password").roles("USER") .and()
	 * .withUser("admin").password("{noop}password").roles("USER", "ADMIN");
	 * 
	 * }
	 * 
	 */	
}
