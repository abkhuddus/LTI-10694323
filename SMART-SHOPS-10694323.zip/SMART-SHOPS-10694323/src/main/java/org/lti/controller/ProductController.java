package org.lti.controller;

import java.util.List;

import org.lti.dto.ProductDto;
import org.lti.exception.ItemNotFoundException;
import org.lti.model.ShopProduct;
import org.lti.service.ShopService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class ProductController {
	
	@Autowired
	private ShopService service;
	
	
	
	@PostMapping("/save")
	public ResponseEntity<?> save(@RequestBody ProductDto product) throws ItemNotFoundException {
		ShopProduct p=service.save(product);	
	  if(p==null) {
		  return new ResponseEntity<String>("Product Not Saved",HttpStatus.FAILED_DEPENDENCY);
	  }
	  return new ResponseEntity<ShopProduct>(p,HttpStatus.CREATED); 
	}
	
	@PostMapping("/update")
	public ResponseEntity<?> update(@RequestBody ProductDto product) throws ItemNotFoundException {
		ShopProduct p=service.update(product);
	  if(p==null) {
		  return new ResponseEntity<String>("Product Not Update",HttpStatus.FAILED_DEPENDENCY);
	  }
	  return new ResponseEntity<ShopProduct>(p,HttpStatus.CREATED); 
	}
	
	
	@GetMapping("/getAllProduct")
	public ResponseEntity<?>getallProducts() throws ItemNotFoundException{
		System.out.println("getAllProduct");
		List<ShopProduct>productList=service.getAllProduct();
		if(!productList.isEmpty()) {
			return new ResponseEntity<List<ShopProduct>>(productList,HttpStatus.OK);
		}else
			 throw new ItemNotFoundException("Product List Not Found In DataBase");
		
		  //return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		
	}

	@GetMapping("/getByName/{name}")
	private ResponseEntity<?> getByName(@PathVariable("name")String name) throws ItemNotFoundException {
	  ProductDto dto=service.getByProductName(name);
		if(dto!=null) {
			return new ResponseEntity<ProductDto>(dto,HttpStatus.OK);
		}else
			throw new ItemNotFoundException("Product Not Found");
	}
	
	@GetMapping("/getByCategory/{category}")
	private ResponseEntity<?> getByCategory(@PathVariable("category")String category) throws ItemNotFoundException {
	  ProductDto dto=service.getByProductCategory(category);
		if(dto!=null) {
			return new ResponseEntity<ProductDto>(dto,HttpStatus.OK);
		}else
			throw new ItemNotFoundException("Product Not Found");
	}
	
	@GetMapping("/setTotalPrice/{id}")
	private ResponseEntity<?> setExpiryProductExpiryDate(@PathVariable("id")Integer id) throws ItemNotFoundException {
	  String updateMsg=service.updatedTotalPrice(id);
	  
			return new ResponseEntity<>(updateMsg,HttpStatus.OK);
	}

 
   
   @DeleteMapping("/deleteLessRetingsProduct")
   public ResponseEntity<?>deleteLessRetingsProduct() throws ItemNotFoundException{
	
	  Integer d= service.deleteProductLessRetings();
	   if(d==0) {
		   return new ResponseEntity<>("No Less Retings Product Found",HttpStatus.NOT_FOUND);
	   }else {
		   return new ResponseEntity<Integer>(d,HttpStatus.OK);
	   }
   }
   
   
   
}
