package com.lti.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.model.Customer;
import com.lti.repo.ProducerRepository;

@Service
public class CustomerServiceImpl implements CustomerService {

	
	@Autowired
	private ProducerRepository repo;
	@Override
	public Customer save(Customer customer) {
		return repo.save(customer);
	}

	@Override
	public Customer getByid(Integer id) {
		 Customer c=repo.findOne(id);
		 if(c!=null) {
			 return c;
		 }
		return null;
	}

	@Override
	public List<Customer> getAll() {
	
		return repo.findAll();
	}

	@Override
	public boolean deleteById(Integer id) {
		
		Customer c=repo.findOne(id);
		if(c!=null) {
			repo.delete(c);
			return true;
		}
		return false;
	}

	@Override
	public boolean update(Customer customer) {
		if(customer!=null) {
			Customer c=repo.findOne(customer.getId());
	         repo.save(c);
		}
		return false;
	}

}
